# VASTU VEDA Numerology — Android Studio project

Brand: **VASTU VEDA by Punit Bhojwani**

This is an Android WebView app project wrapping the current Numerology prototype. It includes:
- Client name and DOB
- Optional 10-digit mobile (country code excluded)
- Optional business/brand name and consultant notes
- Starter Chaldean calculations and report preview
- English / Hindi / Marathi interface labels
- Local device/browser storage for saved clients
- Print / Save PDF (availability depends on Android WebView/print service)

## Build APK
1. Install Android Studio (latest stable) on a computer.
2. Open this folder (`VastuVedaAndroid`) in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show **Locate**; the debug APK is typically at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer APK to your Android phone, tap it, and allow installation from that source if Android asks.

## Important
- This zip is the **Android source project**, not a precompiled APK.
- Saved client records currently remain on the device in WebView storage; they are not encrypted cloud records.
- The numerology interpretation content is starter material and should be reviewed/customized before commercial client reports.
- The current prototype is not yet the complete 15–25-page report editor / production-ready cloud application.
